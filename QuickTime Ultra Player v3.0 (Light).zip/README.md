# QuickTime Ultra Player

Welcome to **QuickTime Ultra Player**! Apple, the original developer of the classic QuickTime Player software, is never going to be updating it again. So, I am here on this software to update it and basically how I created this for you guys to see if you like it. This project revives the iconic aesthetic while providing a powerful, high-performance 'Ultra' experience natively on Windows.

## 🌟 Features

* **High-Performance Playback:** Smoothly plays high-resolution media, including 4K video.
* **Modern Interface:** Three built-in themes (Classic Silver, Dark Carbon, and Ultra Black).
* **Virus & Malware Protection:** Scans media file "magic bytes" (deep headers) to prevent executing viruses disguised as video files (e.g., hidden `.exe` files).
* **Multi-format Support:** Handles `.mp4`, `.mkv`, `.avi`, and `.mp3` (featuring a dedicated audio-only mode).
* **Advanced Scrubber:** Smooth, natively animated timeline scrubbing and frame-by-frame steps.
* **Lightweight:** Designed to consume minimal system memory with automated memory garbage collection.

## 💾 Download & Installation

You can download the latest version of QuickTime Ultra directly from the Releases page.

### Automatic Installation (Recommended)

1. Go to the [Releases](https://github.com/your-username/quicktime-ultra-player/releases) page.
2. Download the `QuickTimeUltraInstaller.exe` file.
3. Run the installer and follow the prompt. It will automatically create desktop shortcuts and place everything where it belongs.

### Manual Installation (Portable)

1. Download the `.zip` archive from the latest Release.
2. Extract the folder anywhere on your PC.
3. Double-click `QuickTimeUltra.exe` to launch the player!

## ⌨️ Keyboard Shortcuts

* **Space:** Play / Pause
* **[ / ]:** Step Backward / Step Forward by frame
* **Ctrl+O:** Open File
* **Ctrl+W:** Clear Media
* **Ctrl+S:** Take Snapshot
* **Ctrl+R:** Reset View
* **Double-click Video:** Fullscreen

## 🛡️ Security Note
If you try to load a media file and see a "Security Alert", the file has been flagged by QuickTime Ultra's embedded heuristic scanner as potentially malicious (such as an executable disguised as an MP4). The player will block it to protect your computer.

---
*Disclaimer: QuickTime Ultra Player is an independent, community-driven application and is not affiliated with, endorsed, or sponsored by Apple Inc.*
